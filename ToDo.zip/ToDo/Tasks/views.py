from django.shortcuts import render,redirect

# Create your views here.
from .models import Tasks
from .forms import TasksForm


def index(request):
    tasks = Tasks.objects.all()

    form = TasksForm() # with this we can get form in html
    if request.method== 'POST':
        form=TasksForm(request.POST)
        if form.is_valid():
            form.save()
        return redirect('/')
    context = {'tasks':tasks,'form':form}
    return render(request,"Tasks/index.html",context)

def update(request,pk):
    tasks = Tasks.objects.get(id=pk)   ## get particular data based on id
    form = TasksForm(instance=tasks)   ## create form for that id and load its data
    if request.method == 'POST':
        form = TasksForm(request.POST,instance=tasks)    ## for update
        if form.is_valid():
            form.save()
        return redirect('/')

    context = { 'form': form}
    return render(request,'Tasks/update.html',context)